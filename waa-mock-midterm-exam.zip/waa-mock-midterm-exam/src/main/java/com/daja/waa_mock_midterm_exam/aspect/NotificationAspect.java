package com.daja.waa_mock_midterm_exam.aspect;

import com.daja.waa_mock_midterm_exam.entity.dto.response.StudentDetailDto;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import java.util.List;

@Aspect
@Component
public class NotificationAspect {

    @AfterReturning(pointcut = "execution(* com.daja.waa_mock_midterm_exam.controller.StudentController.*(..)) && @annotation(org.springframework.web.bind.annotation.GetMapping)", returning = "result")
    public void sendAlert(JoinPoint joinPoint, Object result) {
        if (result instanceof List<?> resultList) {
            if (!resultList.isEmpty() && resultList.getFirst() instanceof StudentDetailDto) {
                System.out.println("Alert: A method returning a list of students was called.");
            }
        }
    }
}
