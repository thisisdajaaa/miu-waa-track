package com.daja.waa_mock_midterm_exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaaMockMidtermExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
